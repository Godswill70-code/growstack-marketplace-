import Head from 'next/head';
export default function Home() {
  return (
    <div>
      <Head><title>Growstack Marketplace</title></Head>
      <main className="p-4">
        <h1 className="text-3xl font-bold">Welcome to Growstack Marketplace</h1>
        <p className="mt-2">Sell courses & ebooks. Earn as an affiliate.</p>
      </main>
    </div>
  );
}