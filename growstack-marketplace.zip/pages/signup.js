export default function Signup() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Sign Up</h1>
      <form className="mt-4 flex flex-col gap-2">
        <input type="text" placeholder="Full Name" className="border p-2" />
        <input type="email" placeholder="Email" className="border p-2" />
        <input type="password" placeholder="Password" className="border p-2" />
        <button className="bg-black text-white p-2">Sign Up</button>
      </form>
    </div>
  );
}